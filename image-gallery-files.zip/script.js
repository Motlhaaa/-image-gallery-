﻿const display = document.getElementById("image");
const previews = document.querySelectorAll(".preview");

function upDate(previewPic) {
  console.log("Preview activated", previewPic.alt, previewPic.src);
  display.textContent = previewPic.alt;
  display.style.backgroundImage = `url("${previewPic.src}")`;
}

function undo() {
  display.style.backgroundImage = "url('')";
  display.textContent = "Hover over an image below to display here.";
}

previews.forEach((previewPic) => {
  previewPic.addEventListener("mouseover", () => upDate(previewPic));
  previewPic.addEventListener("mouseleave", undo);
  previewPic.addEventListener("focus", () => upDate(previewPic));
  previewPic.addEventListener("blur", undo);
});
